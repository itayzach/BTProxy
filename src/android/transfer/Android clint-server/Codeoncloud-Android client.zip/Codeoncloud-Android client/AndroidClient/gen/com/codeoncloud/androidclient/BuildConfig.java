/** Automatically generated file. DO NOT MODIFY */
package com.codeoncloud.androidclient;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}